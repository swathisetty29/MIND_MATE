
import { Mood, User } from './types';

export const COLORS = {
  primary: '#2DD4BF', // Teal-400
  secondary: '#818CF8', // Indigo-400
  background: '#F8FAFC',
  card: '#FFFFFF',
  text: '#1E293B'
};

export const MOCK_USERS: User[] = [
  {
    id: 'u1',
    name: 'Sarah Chen',
    avatar: 'https://picsum.photos/seed/sarah/200',
    mood: Mood.CALM,
    about: 'At peace with the process 🌿',
    quote: 'The soul always knows what to do to heal itself.',
    bio: 'Finding peace through watercolor painting and morning walks. I believe in the power of slow living.',
    interests: ['Art', 'Nature', 'Meditation'],
    connectionStatus: 'none'
  },
  {
    id: 'u2',
    name: 'Marcus Thorne',
    avatar: 'https://picsum.photos/seed/marcus/200',
    mood: Mood.ANXIOUS,
    about: 'One step at a time 🏃‍♂️',
    quote: 'You don’t have to see the whole staircase, just take the first step.',
    bio: 'Dealing with work stress, looking for someone to talk to about productivity and burnout. Coffee enthusiast.',
    interests: ['Coding', 'Gaming', 'Productivity'],
    connectionStatus: 'none'
  },
  {
    id: 'u3',
    name: 'Elena Rodriguez',
    avatar: 'https://picsum.photos/seed/elena/200',
    mood: Mood.HOPEFUL,
    about: 'Sunnier days ahead! ☀️',
    quote: 'Hope is the only thing stronger than fear.',
    bio: 'Recovering from a tough year, feeling better every day! Always down for a gym session or a healthy cook-off.',
    interests: ['Fitness', 'Cooking', 'Self-improvement'],
    connectionStatus: 'none'
  },
  {
    id: 'u4',
    name: 'David Kim',
    avatar: 'https://picsum.photos/seed/david/200',
    mood: Mood.SAD,
    about: 'Searching for the melody 🎵',
    quote: 'Where words fail, music speaks.',
    bio: 'Missing home a bit. Looking for some cheerful conversation and music recommendations to lift the spirits.',
    interests: ['Music', 'Travel', 'Movies'],
    connectionStatus: 'pending'
  }
];
