
import { GoogleGenAI, Type } from "@google/genai";
import { Mood, SessionAnalysis } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getAiFriendResponse = async (history: {role: string, parts: {text: string}[]}[], message: string) => {
  const chat = ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: {
      systemInstruction: "You are MindMate, a jovial, friendly, and highly motivational AI companion. Your goal is to listen deeply and provide supportive, empathetic, and occasionally humorous encouragement. Keep your tone light but sincere. Focus on active listening.",
    }
  });

  const response = await chat.sendMessage({ message });
  return response.text;
};

export const analyzeSentiment = async (text: string): Promise<SessionAnalysis> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analyze the following text for emotional tone and sentiment. Provide a primary mood and short advice. Text: "${text}"`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          sentiment: { type: Type.STRING },
          primaryMood: { 
            type: Type.STRING,
            description: "Must be one of: Anxious, Calm, Energetic, Sad, Hopeful, Frustrated"
          },
          advice: { type: Type.STRING }
        },
        required: ["sentiment", "primaryMood", "advice"]
      }
    }
  });

  return JSON.parse(response.text);
};
