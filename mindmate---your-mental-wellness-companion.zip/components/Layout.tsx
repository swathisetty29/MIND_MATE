
import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';

interface LayoutProps {
  children: React.ReactNode;
  user: any;
  onLogout: () => void;
}

export const Layout: React.FC<LayoutProps> = ({ children, user, onLogout }) => {
  const location = useLocation();
  const navigate = useNavigate();

  const navItems = [
    { path: '/', label: 'Home', icon: '🏠' },
    { path: '/private', label: 'AI Friend', icon: '🤖' },
    { path: '/live', label: 'Real-time Listen', icon: '🎙️' },
    { path: '/community', label: 'Community', icon: '🤝' },
    { path: '/settings', label: 'Settings', icon: '⚙️' },
  ];

  if (!user) return <>{children}</>;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row">
      {/* Mobile Header */}
      <div className="md:hidden bg-white border-b p-4 flex justify-between items-center sticky top-0 z-50">
        <h1 className="text-xl font-bold text-teal-600">MindMate</h1>
        <button 
          onClick={onLogout}
          className="text-xs font-bold text-rose-500 bg-rose-50 px-3 py-1 rounded-full"
        >
          Logout
        </button>
      </div>

      {/* Sidebar Navigation */}
      <nav className="w-full md:w-64 bg-white border-r md:h-screen flex flex-row md:flex-col fixed bottom-0 md:sticky md:top-0 z-40 shadow-sm md:shadow-none">
        <div className="hidden md:block p-6">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-teal-500 to-indigo-600 bg-clip-text text-transparent">MindMate</h1>
          <p className="text-xs text-slate-400 mt-1">Your mental wellness ally</p>
        </div>

        <div className="flex-1 flex md:flex-col overflow-x-auto md:overflow-y-auto">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`flex-1 md:flex-none flex flex-col md:flex-row items-center p-3 md:px-6 md:py-4 gap-3 transition-colors ${
                location.pathname === item.path 
                  ? 'bg-teal-50 text-teal-600 border-t-2 md:border-t-0 md:border-l-4 border-teal-500' 
                  : 'text-slate-500 hover:bg-slate-50'
              }`}
            >
              <span className="text-xl">{item.icon}</span>
              <span className="text-xs md:text-sm font-medium">{item.label}</span>
            </Link>
          ))}
        </div>

        <div className="hidden md:block p-4 border-t">
          <div className="flex items-center gap-3 p-2 bg-slate-50 rounded-2xl mb-4">
            <img src={user.avatar} className="w-8 h-8 rounded-full" alt="profile" />
            <div className="flex-1 min-w-0">
              <p className="text-xs font-bold text-slate-700 truncate">{user.name}</p>
              <p className="text-[10px] text-slate-400 truncate">{user.email}</p>
            </div>
          </div>
          <button 
            onClick={onLogout}
            className="w-full flex items-center justify-center gap-2 py-2 text-rose-500 text-sm font-bold hover:bg-rose-50 rounded-xl transition-colors"
          >
            <span>🚪</span> Logout
          </button>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1 pb-24 md:pb-0 overflow-y-auto">
        <div className="max-w-5xl mx-auto p-4 md:p-8">
          {children}
        </div>
      </main>
    </div>
  );
};
