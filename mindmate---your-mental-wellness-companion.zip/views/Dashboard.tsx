
import React, { useState, useEffect } from 'react';
import { Mood, AuthUser } from '../types';

export const Dashboard: React.FC = () => {
  const [selectedMood, setSelectedMood] = useState<Mood | null>(null);
  const [currentUser, setCurrentUser] = useState<AuthUser | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem('mindmate_user');
    if (stored) setCurrentUser(JSON.parse(stored));
  }, []);

  const moods = [
    { mood: Mood.CALM, emoji: '😌', color: 'bg-emerald-100 text-emerald-700' },
    { mood: Mood.ANXIOUS, emoji: '😟', color: 'bg-amber-100 text-amber-700' },
    { mood: Mood.ENERGETIC, emoji: '⚡', color: 'bg-yellow-100 text-yellow-700' },
    { mood: Mood.SAD, emoji: '😢', color: 'bg-blue-100 text-blue-700' },
    { mood: Mood.HOPEFUL, emoji: '✨', color: 'bg-teal-100 text-teal-700' },
    { mood: Mood.FRUSTRATED, emoji: '😤', color: 'bg-rose-100 text-rose-700' },
  ];

  return (
    <div className="space-y-8 animate-fadeIn pb-12">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div className="space-y-2">
          <h2 className="text-3xl font-bold text-slate-800">Hello, {currentUser?.name?.split(' ')[0] || 'Friend'}! 👋</h2>
          <p className="text-teal-600 font-medium italic">{currentUser?.about || 'How are you feeling today?'}</p>
        </div>
        {currentUser?.quote && (
           <div className="max-w-xs text-right hidden md:block">
              <p className="text-[10px] text-slate-400 uppercase tracking-widest font-bold mb-1">Your Quote</p>
              <p className="text-xs text-slate-500 italic">"{currentUser.quote}"</p>
           </div>
        )}
      </header>

      <section className="grid grid-cols-3 md:grid-cols-6 gap-4">
        {moods.map((m) => (
          <button
            key={m.mood}
            onClick={() => setSelectedMood(m.mood)}
            className={`flex flex-col items-center p-4 rounded-2xl border-2 transition-all hover:scale-105 ${
              selectedMood === m.mood 
                ? 'border-teal-500 bg-teal-50 shadow-md' 
                : 'border-transparent bg-white shadow-sm'
            }`}
          >
            <span className="text-4xl mb-2">{m.emoji}</span>
            <span className="text-xs font-semibold">{m.mood}</span>
          </button>
        ))}
      </section>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 group hover:border-teal-200 transition-colors">
          <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
            <span className="group-hover:animate-bounce">✨</span> Daily Motivation
          </h3>
          <p className="text-slate-600 italic">
            "Your mental health is a priority. Your happiness is an essential. Your self-care is a necessity."
          </p>
          <div className="mt-6 flex gap-3">
            <button className="bg-teal-500 text-white px-6 py-2 rounded-full text-sm font-semibold hover:bg-teal-600 transition-colors shadow-lg shadow-teal-100">
              Get AI Advice
            </button>
          </div>
        </div>

        <div className="bg-gradient-to-br from-indigo-500 to-purple-600 p-6 rounded-3xl shadow-lg text-white">
          <h3 className="text-lg font-bold mb-2">Connect & Grow</h3>
          <p className="text-indigo-100 text-sm mb-6">
            There are peers online who share your baseline mood right now.
          </p>
          <button className="bg-white text-indigo-600 px-6 py-2 rounded-full text-sm font-semibold hover:bg-indigo-50 transition-colors">
            Find Matches
          </button>
        </div>
      </div>

      <section className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
        <h3 className="text-lg font-bold mb-4">Activity Log</h3>
        <div className="space-y-4">
          <div className="flex items-center p-3 bg-slate-50 rounded-xl">
            <div className="w-10 h-10 bg-teal-100 text-teal-600 rounded-full flex items-center justify-center mr-4">🧘</div>
            <div className="flex-1">
              <h4 className="text-sm font-semibold">Morning Meditation</h4>
              <p className="text-xs text-slate-400">Recommended for your mood</p>
            </div>
            <button className="text-teal-600 text-sm font-bold bg-white px-4 py-1.5 rounded-lg border border-teal-100 shadow-sm">Start</button>
          </div>
          <div className="flex items-center p-3 bg-slate-50 rounded-xl">
            <div className="w-10 h-10 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center mr-4">📖</div>
            <div className="flex-1">
              <h4 className="text-sm font-semibold">Reflective Journaling</h4>
              <p className="text-xs text-slate-400">Last entry: Today, 9:30 AM</p>
            </div>
            <div className="bg-green-100 text-green-600 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold">✓</div>
          </div>
        </div>
      </section>
    </div>
  );
};
