
import React from 'react';
import { Link } from 'react-router-dom';

export const Landing: React.FC = () => {
  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center p-6 text-center overflow-hidden relative">
      {/* Decorative background elements */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-teal-50 rounded-full blur-3xl opacity-50 animate-pulse"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-indigo-50 rounded-full blur-3xl opacity-50 animate-pulse" style={{ animationDelay: '1s' }}></div>

      <div className="max-w-3xl w-full space-y-12 relative z-10 animate-fadeIn">
        <header className="space-y-6">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-teal-50 text-teal-600 rounded-full text-xs font-bold uppercase tracking-widest shadow-sm">
            <span>✨</span> Your Mental Wellness Sanctuary
          </div>
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight text-slate-900 leading-tight">
            Mind<span className="text-teal-500">Mate</span>
          </h1>
          <p className="text-xl md:text-2xl text-slate-500 max-w-2xl mx-auto font-medium leading-relaxed">
            Taking care of your mental health is just as important as physical strength. 
            <span className="block mt-2 text-indigo-500 italic">Because your mind matters.</span>
          </p>
        </header>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link
            to="/signup"
            className="w-full sm:w-auto px-10 py-4 bg-teal-500 text-white rounded-2xl font-bold text-lg hover:bg-teal-600 transition-all shadow-xl shadow-teal-100 hover:scale-105 active:scale-95"
          >
            Start Your Journey
          </Link>
          <Link
            to="/login"
            className="w-full sm:w-auto px-10 py-4 bg-white text-slate-700 border-2 border-slate-100 rounded-2xl font-bold text-lg hover:border-teal-200 hover:bg-slate-50 transition-all hover:scale-105 active:scale-95"
          >
            Welcome Back
          </Link>
        </div>

        <section className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-12">
          <div className="p-6 bg-slate-50 rounded-3xl space-y-3">
            <div className="text-3xl">🤖</div>
            <h3 className="font-bold text-slate-800">AI Companion</h3>
            <p className="text-sm text-slate-500">A friendly ear available 24/7 to listen and motivate.</p>
          </div>
          <div className="p-6 bg-slate-50 rounded-3xl space-y-3">
            <div className="text-3xl">🎙️</div>
            <h3 className="font-bold text-slate-800">Real-time Listen</h3>
            <p className="text-sm text-slate-500">Express yourself through voice and video with AI empathy.</p>
          </div>
          <div className="p-6 bg-slate-50 rounded-3xl space-y-3">
            <div className="text-3xl">🤝</div>
            <h3 className="font-bold text-slate-800">Peer Support</h3>
            <p className="text-sm text-slate-500">Connect with others on similar paths safely.</p>
          </div>
        </section>
      </div>

      <footer className="absolute bottom-8 left-0 w-full text-center">
        <p className="text-slate-400 text-xs font-medium uppercase tracking-widest">
          Created for your well-being
        </p>
      </footer>
    </div>
  );
};
