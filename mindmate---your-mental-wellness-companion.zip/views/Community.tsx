
import React, { useState } from 'react';
import { MOCK_USERS } from '../constants';
import { User, Mood } from '../types';

export const Community: React.FC = () => {
  const [users, setUsers] = useState<User[]>(MOCK_USERS);
  const [filter, setFilter] = useState<Mood | 'All'>('All');

  const handleConnect = (id: string) => {
    setUsers(prev => prev.map(u => 
      u.id === id ? { ...u, connectionStatus: 'pending' } : u
    ));
  };

  const filteredUsers = filter === 'All' 
    ? users 
    : users.filter(u => u.mood === filter);

  return (
    <div className="space-y-8 animate-fadeIn pb-12">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Peer Community</h2>
          <p className="text-slate-500">Connect with people on similar paths.</p>
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2 md:pb-0">
          {['All', ...Object.values(Mood)].map((m) => (
            <button
              key={m}
              onClick={() => setFilter(m as any)}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-colors ${
                filter === m ? 'bg-teal-500 text-white shadow-md' : 'bg-white text-slate-500 border border-slate-200'
              }`}
            >
              {m}
            </button>
          ))}
        </div>
      </header>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredUsers.map((user) => (
          <div key={user.id} className="bg-white p-6 rounded-3xl border border-slate-100 hover:shadow-xl transition-all group relative flex flex-col">
            <div className="absolute top-4 right-4">
              <span className={`text-[10px] px-2 py-1 rounded-full font-bold uppercase ${
                user.mood === Mood.ANXIOUS ? 'bg-amber-100 text-amber-600' :
                user.mood === Mood.CALM ? 'bg-emerald-100 text-emerald-600' :
                user.mood === Mood.SAD ? 'bg-blue-100 text-blue-600' :
                'bg-teal-100 text-teal-600'
              }`}>
                {user.mood}
              </span>
            </div>
            
            <div className="flex items-center gap-4 mb-4">
              <img src={user.avatar} alt={user.name} className="w-16 h-16 rounded-2xl object-cover ring-2 ring-slate-50 shadow-sm" />
              <div className="flex-1 min-w-0">
                <h3 className="font-bold text-slate-800 truncate">{user.name}</h3>
                <p className="text-xs text-teal-600 font-medium truncate">{user.about}</p>
              </div>
            </div>

            <div className="mb-4 bg-slate-50/50 p-3 rounded-2xl border border-slate-100/50">
               <p className="text-sm text-slate-500 italic relative pl-4">
                 <span className="absolute left-0 top-0 text-teal-300 text-xl font-serif">“</span>
                 {user.quote}
               </p>
            </div>

            <p className="text-sm text-slate-600 line-clamp-3 mb-6 flex-1">
              {user.bio}
            </p>

            <div className="flex flex-wrap gap-1 mb-6">
              {user.interests.map(i => (
                <span key={i} className="text-[10px] bg-indigo-50 text-indigo-500 px-2 py-0.5 rounded-lg font-medium">#{i}</span>
              ))}
            </div>

            <div className="mt-auto">
              <button
                disabled={user.connectionStatus !== 'none'}
                onClick={() => handleConnect(user.id)}
                className={`w-full py-2.5 rounded-xl text-sm font-bold transition-all ${
                  user.connectionStatus === 'none' 
                    ? 'bg-teal-500 text-white hover:bg-teal-600 shadow-md shadow-teal-100' 
                    : user.connectionStatus === 'pending'
                    ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                    : 'bg-indigo-50 text-indigo-600'
                }`}
              >
                {user.connectionStatus === 'none' ? 'Send Connection' : 
                 user.connectionStatus === 'pending' ? 'Request Pending' : 'Message'}
              </button>
            </div>
          </div>
        ))}
      </div>

      {filteredUsers.length === 0 && (
        <div className="text-center py-20 bg-white rounded-3xl border border-dashed border-slate-200">
          <p className="text-slate-400">No peers found matching this mood. Try expanding your search!</p>
        </div>
      )}
    </div>
  );
};
