
import React, { useState } from 'react';
import { Mood, AuthUser } from '../types';

interface SettingsProps {
  user: AuthUser;
  onUpdateUser: (updates: Partial<AuthUser>) => void;
}

export const Settings: React.FC<SettingsProps> = ({ user, onUpdateUser }) => {
  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [about, setAbout] = useState(user?.about || '');
  const [quote, setQuote] = useState(user?.quote || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [preferredMood, setPreferredMood] = useState<Mood>(user?.preferredMood || Mood.CALM);
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = () => {
    setIsSaving(true);
    setTimeout(() => {
      onUpdateUser({ name, email, about, quote, bio, preferredMood });
      setIsSaving(false);
      alert('Profile updated successfully!');
    }, 800);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8 animate-fadeIn pb-12">
      <header>
        <h2 className="text-2xl font-bold text-slate-800">Account Settings</h2>
        <p className="text-slate-500">How you appear to the MindMate community.</p>
      </header>

      <section className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm space-y-6">
        <div className="flex items-center gap-6 pb-6 border-b border-slate-50">
          <div className="relative">
            <img src={user?.avatar} alt="Profile" className="w-20 h-20 rounded-3xl object-cover ring-4 ring-teal-50" />
            <button className="absolute -bottom-2 -right-2 bg-white p-1.5 rounded-xl shadow-md border border-slate-100 text-teal-600">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
            </button>
          </div>
          <div>
            <h4 className="font-bold text-slate-800">{user?.name}</h4>
            <p className="text-sm text-teal-600 font-medium italic">"{about || 'Set a status...'}"</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Display Name</label>
              <input 
                type="text" 
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-slate-50 border-transparent focus:bg-white focus:ring-2 focus:ring-teal-500 transition-all text-sm outline-none"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">About (Status)</label>
              <input 
                type="text" 
                value={about}
                placeholder="e.g., Dreaming big ✨"
                onChange={(e) => setAbout(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-slate-50 border-transparent focus:bg-white focus:ring-2 focus:ring-teal-500 transition-all text-sm outline-none"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Personal Quote</label>
            <input 
              type="text" 
              value={quote}
              placeholder="Your favorite inspirational quote..."
              onChange={(e) => setQuote(e.target.value)}
              className="w-full px-4 py-3 rounded-xl bg-slate-50 border-transparent focus:bg-white focus:ring-2 focus:ring-teal-500 transition-all text-sm outline-none italic"
            />
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Bio / Story</label>
            <textarea 
              value={bio}
              rows={3}
              placeholder="Tell others a bit about your journey..."
              onChange={(e) => setBio(e.target.value)}
              className="w-full px-4 py-3 rounded-xl bg-slate-50 border-transparent focus:bg-white focus:ring-2 focus:ring-teal-500 transition-all text-sm outline-none resize-none"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Email Address</label>
              <input 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-slate-50 border-transparent focus:bg-white focus:ring-2 focus:ring-teal-500 transition-all text-sm outline-none"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-wider">Baseline Mood</label>
              <select
                value={preferredMood}
                onChange={(e) => setPreferredMood(e.target.value as Mood)}
                className="w-full px-4 py-3 rounded-xl bg-slate-50 border-transparent focus:bg-white focus:ring-2 focus:ring-teal-500 transition-all text-sm outline-none appearance-none"
              >
                {Object.values(Mood).map(m => (
                  <option key={m} value={m}>{m}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="pt-6 border-t border-slate-50 flex justify-end">
          <button 
            onClick={handleSave}
            disabled={isSaving}
            className="bg-teal-500 text-white px-8 py-2.5 rounded-xl font-bold hover:bg-teal-600 transition-all shadow-lg shadow-teal-100 disabled:opacity-50"
          >
            {isSaving ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </section>

      <section className="bg-rose-50 p-6 rounded-3xl border border-rose-100 shadow-sm">
        <h4 className="text-rose-700 font-bold mb-2">Danger Zone</h4>
        <p className="text-rose-600/70 text-sm mb-4">Deleting your account is permanent. All your data will be cleared.</p>
        <button className="text-rose-600 font-bold text-sm hover:underline">
          Delete Account
        </button>
      </section>
    </div>
  );
};
