
export enum Mood {
  ANXIOUS = 'Anxious',
  CALM = 'Calm',
  ENERGETIC = 'Energetic',
  SAD = 'Sad',
  HOPEFUL = 'Hopeful',
  FRUSTRATED = 'Frustrated'
}

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  avatar: string;
  preferredMood?: Mood;
  about?: string; // Short status like WhatsApp
  quote?: string; // Favorite inspirational quote
  bio?: string;   // Longer personal description
}

export interface User {
  id: string;
  name: string;
  avatar: string;
  mood: Mood;
  about: string;
  quote: string;
  bio: string;
  interests: string[];
  connectionStatus: 'none' | 'pending' | 'connected';
}

export interface Message {
  id: string;
  senderId: string;
  text: string;
  timestamp: Date;
  isAi?: boolean;
}

export interface SessionAnalysis {
  sentiment: string;
  primaryMood: Mood;
  advice: string;
}
